(1...20).each do |n|
  map = "ra3map#{n}"
  Dir::chdir(File::join(["resources", map, "levelshots"]))
  Dir['*.*'].each do |img|
    img_root = img.split(".").first
    puts "convert -crop 400x400 #{File::join([Dir::pwd, img])} #{File::join([Dir::pwd, img_root])}_400x400.png"
  end
  Dir::chdir(File::join(["..", "arenashots"]))
  Dir['*.*'].each do |img|
    img_root = img.split(".").first
    puts "convert #{File::join([Dir::pwd, img])} #{File::join([Dir::pwd, img_root])}.png"
  end
  Dir::chdir(File::join(["..", "..", ".."]))
end
