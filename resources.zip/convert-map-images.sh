convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map1/levelshots/ra3map1.jpg /home/cfox/personal/projects/q3stats/resources/ra3map1/levelshots/ra3map1_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map1/arenashots/ra3map1_3.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map2/levelshots/ra3map2.jpg /home/cfox/personal/projects/q3stats/resources/ra3map2/levelshots/ra3map2_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map2/arenashots/ra3map2_2.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map3/levelshots/ra3map3.tga /home/cfox/personal/projects/q3stats/resources/ra3map3/levelshots/ra3map3_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_5.tga /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_5.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map3/arenashots/ra3map3_4.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map4/levelshots/ra3map4.tga /home/cfox/personal/projects/q3stats/resources/ra3map4/levelshots/ra3map4_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map4/arenashots/ra3map4_4.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map5/levelshots/ra3map5.tga /home/cfox/personal/projects/q3stats/resources/ra3map5/levelshots/ra3map5_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map5/arenashots/ra3map5_4.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map6/levelshots/ra3map6.jpg /home/cfox/personal/projects/q3stats/resources/ra3map6/levelshots/ra3map6_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map6/arenashots/ra3map6_2.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map7/levelshots/ra3map7.tga /home/cfox/personal/projects/q3stats/resources/ra3map7/levelshots/ra3map7_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map7/arenashots/ra3map7_1.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map8/levelshots/ra3map8.jpg /home/cfox/personal/projects/q3stats/resources/ra3map8/levelshots/ra3map8_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_5.tga /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_5.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map8/arenashots/ra3map8_3.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map9/levelshots/ra3map9.jpg /home/cfox/personal/projects/q3stats/resources/ra3map9/levelshots/ra3map9_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_3.jpg /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_1.jpg /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_2.jpg /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_4.jpg /home/cfox/personal/projects/q3stats/resources/ra3map9/arenashots/ra3map9_4.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map10/levelshots/ra3map10.jpg /home/cfox/personal/projects/q3stats/resources/ra3map10/levelshots/ra3map10_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map10/arenashots/ra3map10_2.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map11/levelshots/ra3map11.jpg /home/cfox/personal/projects/q3stats/resources/ra3map11/levelshots/ra3map11_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map11/arenashots/ra3map11_2.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map12/levelshots/ra3map12.jpg /home/cfox/personal/projects/q3stats/resources/ra3map12/levelshots/ra3map12_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map12/arenashots/ra3map12_2.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map13/levelshots/ra3map13.jpg /home/cfox/personal/projects/q3stats/resources/ra3map13/levelshots/ra3map13_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_5.tga /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_5.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map13/arenashots/ra3map13_4.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map14/levelshots/ra3map14.jpg /home/cfox/personal/projects/q3stats/resources/ra3map14/levelshots/ra3map14_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_2.jpg /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_4.jpg /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_3.jpg /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_1.jpg /home/cfox/personal/projects/q3stats/resources/ra3map14/arenashots/ra3map14_1.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map15/levelshots/Thumbs.db /home/cfox/personal/projects/q3stats/resources/ra3map15/levelshots/Thumbs_400x400.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map15/levelshots/ra3map15.jpg /home/cfox/personal/projects/q3stats/resources/ra3map15/levelshots/ra3map15_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_4.jpg /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_3.jpg /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_2.jpg /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_5.jpg /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_5.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_1.jpg /home/cfox/personal/projects/q3stats/resources/ra3map15/arenashots/ra3map15_1.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map16/levelshots/ra3map16.jpg /home/cfox/personal/projects/q3stats/resources/ra3map16/levelshots/ra3map16_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map16/arenashots/ra3map16_1.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map17/levelshots/Thumbs.db /home/cfox/personal/projects/q3stats/resources/ra3map17/levelshots/Thumbs_400x400.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map17/levelshots/ra3map17.jpg /home/cfox/personal/projects/q3stats/resources/ra3map17/levelshots/ra3map17_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_3.jpg /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_4.jpg /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/Thumbs.db /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/Thumbs.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_1.jpg /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_2.jpg /home/cfox/personal/projects/q3stats/resources/ra3map17/arenashots/ra3map17_2.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map18/levelshots/ra3map18.jpg /home/cfox/personal/projects/q3stats/resources/ra3map18/levelshots/ra3map18_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_1.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map18/arenashots/ra3map18_4.png
convert -crop 400x400 /home/cfox/personal/projects/q3stats/resources/ra3map19/levelshots/ra3map19.jpg /home/cfox/personal/projects/q3stats/resources/ra3map19/levelshots/ra3map19_400x400.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_3.tga /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_3.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_4.tga /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_4.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_2.tga /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_2.png
convert /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_1.tga /home/cfox/personal/projects/q3stats/resources/ra3map19/arenashots/ra3map19_1.png
