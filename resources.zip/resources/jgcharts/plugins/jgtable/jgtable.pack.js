/*
 * 
 * jQuery Google Charts - Table Plugin 0.9
 * 
 * $Date:2008-06-12 18:32:13 +0200 (gio, 12 giu 2008) $
 * $Rev:171 $
 * 
 * @requires
 * jGCharts Base
 * Metadata
 * 
 * Copyright (c) 2008 Massimiliano Balestrieri
 * Examples and docs at: http://maxb.net/blog/
 * Licensed GPL licenses:
 * http://www.gnu.org/licenses/gpl.html
 *
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<62?'':e(parseInt(c/62)))+((c=c%62)>35?String.fromCharCode(c+29):c.toString(36))};if('0'.replace(0,e)==0){while(c--)r[e(c)]=k[c];k=[function(e){return r[e]||e}];e=function(){return'[1-9n-rt-zA-E]'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('3(!window.5)alert("Include 5 Base Plugin");5.t={u:6(g){7 v.each(6(j,k){2 b=v;2 l=1(b).8("table").w(0);2 a=1.x({o:\'y\'},g);3(!a.z){2 c=1(\'<div class="jgchart">\');1(b).prepend(c)}A{2 c=1(a.z)}a=1.x(1(b).y({cre:/({[\\s\\S]*})/,o:a.o.toString()}),a);3(!a.p){a.p=[];for(2 d=0;d<1(b).8("q > 9").size();d++){a.p.push(1.r(1(b).8("q > 9:w("+d+") > td"),6(e,m){3(B(1(e).n()))7 B(1(e).n());A 7 0}))}}3(!a.C)a.C=1.r(1(b).8("q > 9 > 4.D"),6(4){7 1(4).n()});3(!a.E)a.E=1.r(1(b).8("thead > 9:last > 4.D"),6(4){7 1(4).n()});2 h=new 5.Api();2 i=h.make(a);2 f=1(\'<img>\').attr(\'src\',i);3(a.gui){f.addClass("jggui")}c.append(f)})}};1.fn.jgtable=5.t.u;',[],41,'|jQuery|var|if|th|jGCharts|function|return|find|tr||||||||||||||text|single|data|tbody|map||Table|init|this|eq|extend|metadata|target|else|parseFloat|axis_labels|serie|legend'.split('|'),0,{}))